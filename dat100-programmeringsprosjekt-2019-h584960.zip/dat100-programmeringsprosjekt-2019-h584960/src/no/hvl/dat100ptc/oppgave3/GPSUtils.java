package no.hvl.dat100ptc.oppgave3;

import static java.lang.Math.*;

import no.hvl.dat100ptc.TODO;
import no.hvl.dat100ptc.oppgave1.GPSPoint;

public class GPSUtils {

	public static double findMax(double[] da) {

		double max; 
		
		max = da[0];
		
		for (double d : da) {
			if (d > max) {
				max = d;
			}
		}
		
		return max;
	}

	public static double findMin(double[] da) {

		double min;

		// TODO - START
		
		min = da[0];
		
		for (double d : da) {
			if (d < min) {
				min = d;
			}
		}
		
		return min;

		// TODO - SLUT

	}

	public static double[] getLatitudes(GPSPoint[] gpspoints) {

		// TODO - START
		
		double[] lat = new double[gpspoints.length]; 
		for(int i = 0; i < lat.length; i++) {

			lat[i] = gpspoints[i].getLatitude();
		}
		return lat;
		// TODO - SLUTT
	}

	public static double[] getLongitudes(GPSPoint[] gpspoints) {

		// TODO - START

		double[] lon = new double[gpspoints.length]; 
		for(int i = 0; i < lon.length; i++) {

			lon[i] = gpspoints[i].getLongitude();
		}
		return lon;
		// TODO - SLUTT

	}

	private static int R = 6371000; // jordens radius

	public static double distance(GPSPoint gpspoint1, GPSPoint gpspoint2) {

		double d;
		double latitude1, longitude1, latitude2, longitude2;

		// TODO - START
		
		latitude1 = gpspoint1.getLatitude();
		latitude2 = gpspoint2.getLatitude();
		longitude1 = gpspoint1.getLongitude();
		longitude2 = gpspoint2.getLongitude();
		

		
		double R = 6371000; // metres
		double lat1 = latitude1 * Math.PI / 180;
		double lat2 = latitude2 * Math.PI / 180;
		double lon1 = longitude1 * Math.PI / 180;
		double lon2 = longitude2 * Math.PI / 180;

		double a = Math.sin((lat2 - lat1)/2) * Math.sin((lat2 - lat1)/2) +
		        Math.cos(lat1) * Math.cos(lat2) *
		        Math.sin((lon2 - lon1)/2) * Math.sin((lon2 - lon1)/2);
		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

		d = R * c;
		
		return d;
		
		// TODO - SLUTT

	}

	public static double speed(GPSPoint gpspoint1, GPSPoint gpspoint2) {

		int secs;
		double speed;

		// TODO - START

		secs = gpspoint2.getTime()-gpspoint1.getTime();
		double distance = distance(gpspoint1,gpspoint2);
		speed = (distance / secs) * 3.6;
		return speed;
		// TODO - SLUTT

	}

	public static String formatTime(int secs) {

		String timestr;
		String TIMESEP = ":";

		// TODO - START

		int hourRest = secs % 3600;
		int minRest = hourRest % 60;
		int hour = (secs - hourRest) / 3600;
		int min = (hourRest - minRest) / 60;
		int sec = minRest;
		
		String HS;
		String MS;
		String SS;
		if(String.valueOf(hour).length()<2) {
			HS = "0"+hour;
		}
		else {
			HS = String.valueOf(hour);
		}
		if(String.valueOf(min).length()<2) {
			MS = "0"+min;
		}
		else {
			MS = String.valueOf(min);
		}
		if(String.valueOf(sec).length()<2) {
			SS = "0"+sec;
		}
		else {
			SS = String.valueOf(sec);
		}
		
		
		timestr = HS + TIMESEP + MS + TIMESEP + SS;
		
		while(timestr.length()<10){
			timestr = " "+timestr;
		}
		
		return timestr;
		// TODO - SLUTT

	}
	private static int TEXTWIDTH = 10;

	public static String formatDouble(double d) {

		String str;

		// TODO - START

		d = (int)(d*100+0.5);
		d = (double)(d/100);
		str = String.valueOf(d);
		while(str.length()<10){
			str = " "+str;
		}
		return str;
		// TODO - SLUTT
		
	}
}
